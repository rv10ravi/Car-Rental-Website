import react, { useState, useEffect } from 'react'
import "../styles/contact.css"
import { Container, Row, Col, Form, FormGroup, Input } from "reactstrap";
import { Link } from "react-router-dom";
import CommonSection from "../components/UI/CommonSection";
import Helmet from "../components/Helmet/Helmet";
import axios from 'axios';
import { useNavigate } from "react-router-dom";





const socialLinks = [
    {
        url: "https://www.facebook.com/",
        icon: "ri-facebook-line",
    },
    {
        url: "https://www.instagram.com/",
        icon: "ri-instagram-line",
    },
    {
        url: "https://www.linkedin.com/",
        icon: "ri-linkedin-line",
    },
    {
        url: "https://twitter.com/",
        icon: "ri-twitter-line",
    },
];
const ShowDetails = () => {
    const navigate = useNavigate()

    const [data, setData] = useState({});

    useEffect(() => {
        // Make an API request when the component mounts
        axios.get('http://localhost:8081/users')
            .then((response) => {
                setData(response.data)
            })
            .catch((error) => {
                console.error(error);
            });
    }, []);
    const Logout =()=>{
        navigate("/home")
    }

    return (



        <Helmet title="Register">
            <CommonSection title="User Details" />
            <section>
                <Container>
                    <Row>
                        <Col lg="7" md="7">
                            <h6 className="fw-bold mb-4">User Details</h6>

                            <Form >
                                <FormGroup className="contact__form">

                                    <Input htmlFor="name" placeholder={data.name} name="name" type="text" />
                                </FormGroup>
                                <FormGroup className="contact__form">
                                    <Input htmlFor="email" placeholder={data.email} type="email" name="email" />
                                </FormGroup>
                                <FormGroup className="contact__form">
                                    <Input type="password" placeholder={data.password} />
                                </FormGroup>
                                <FormGroup className="contact__form">
                                    <Input htmlFor="address" placeholder={data.address} type="text" name="address" />
                                </FormGroup>
                                <button className="contact__btn" type="submit" onClick={Logout}>
                                    Logout
                                </button>

                            </Form>
                        </Col>

                        <Col lg="5" md="5">
                            <div className="contact__info">
                                <h6 className="fw-bold">Contact Information</h6>
                                <p className="section__description mb-0">
                                    456 Koramangala Avenue, HSR Layout, Bangalore
                                </p>
                                <div className=" d-flex align-items-center gap-2">
                                    <h6 className="fs-6 mb-0">Phone:</h6>
                                    <p className="section__description mb-0">+917891234567</p>
                                </div>

                                <div className=" d-flex align-items-center gap-2">
                                    <h6 className="mb-0 fs-6">Email:</h6>
                                    <p className="section__description mb-0">bangalorerentalservice@gmail.com </p>
                                </div>

                                <h6 className="fw-bold mt-4">Follow Us</h6>

                                <div className=" d-flex align-items-center gap-4 mt-3">
                                    {socialLinks.map((item, index) => (
                                        <Link
                                            to={item.url}
                                            key={index}
                                            className="social__link-icon"
                                        >
                                            <i class={item.icon}></i>
                                        </Link>
                                    ))}
                                </div>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
        </Helmet>
    )

}

export default ShowDetails;