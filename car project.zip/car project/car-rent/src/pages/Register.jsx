import React from "react";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Container, Row, Col, Form, FormGroup, Input } from "reactstrap";
import Helmet from "../components/Helmet/Helmet";
import CommonSection from "../components/UI/CommonSection";
import axios from 'axios';


import "../styles/contact.css";

const socialLinks = [
  {
    url: "https://www.facebook.com/",
    icon: "ri-facebook-line",
  },
  {
    url: "https://www.instagram.com/",
    icon: "ri-instagram-line",
  },
  {
    url: "https://www.linkedin.com/",
    icon: "ri-linkedin-line",
  },
  {
    url: "https://twitter.com/",
    icon: "ri-twitter-line",
  },
];

const Register = () => {
  const navigate = useNavigate()
  const [values, setValues] = useState({
    name: '',
    email: '',
    password: '',
    address: ''
  })

  const [user, setUser] = useState(true);
  const [password, setPassword] = useState(true);
  const [email, setEmail] = useState(true);
  const [confirm, confirmPass] = useState(true);
  const [address, setAddress] = useState(true);
  const [pass1,setPass1] = useState('');
  const [pass2,setPass2] = useState('');
  function userHandler(e) {
    let item = e.target.value;
    if (item === "") {
      setUser(true);


    }
    else {
      setValues({ ...values, [e.target.name]: [e.target.value] })

      setUser(false);

    }

  }
  function passwordHandler(e) {
    let item = e.target.value;
    if (item === "") {
      setPassword(true);

    }
    else {
      setValues({ ...values, [e.target.name]: [e.target.value] })
      setPassword(false);
      setPass1(e.target.value)

    }

  }
  function emailHandler(e) {
    let item = e.target.value;
    if (item === "") {
      setEmail(true);

    }
    else {
      setValues({ ...values, [e.target.name]: [e.target.value] })

      setEmail(false);

    }

  }
  function confirmHandler(e) {
    let item = e.target.value;
    if (item === "") {
      confirmPass(true);

    }
    else {


      confirmPass(false);
      setPass2(e.target.value)

    }

  }
  function addressHandler(e) {
    let item = e.target.value;
    if (item === "") {
      setAddress(true);

    }
    else {
    
        setValues({ ...values, [e.target.name]: [e.target.value] })

        setAddress(false);
      

    }

  }

  function submitHandler(e) {
    if(pass1 !== pass2)
    {
      alert('check password')
      e.preventDefault();
    }
    else if (!user && !confirm && !address && !email && !password) {
      e.preventDefault();
      axios.post('http://localhost:8081/register', values)
        .then(res => console.log("Registed successfully"))
        .catch(err => console.log(err))
      alert("Submitted successfully");
      navigate('/login')

    }
    else {
      alert("Please fill each row")
      e.preventDefault();
      console.log(user)
    }

  }

  return (
    <Helmet title="Register">
      <CommonSection title="Register" />
      <section>
        <Container>
          <Row>
            <Col lg="7" md="7">
              <h6 className="fw-bold mb-4">Register Here</h6>

              <Form onSubmit={submitHandler} method="post" action="">
                <FormGroup className="contact__form">

                  <Input placeholder="Enter your name here" htmlFor="name" name="name" type="text" onChange={userHandler} />
                  {user ? <span>*required</span> : ""}
                </FormGroup>
                <FormGroup className="contact__form">
                  <Input placeholder="Enter your email address" htmlFor="email" type="email" name="email" onChange={emailHandler} />
                  {email ? <span>*required</span> : ""}
                </FormGroup>
                <FormGroup className="contact__form">
                  <Input placeholder="Enter your password here" htmlFor="password" type="password" name="password" onChange={passwordHandler} />
                  {password ? <span>*required</span> : ""}
                </FormGroup>
                <FormGroup className="contact__form">
                  <Input placeholder="Confirm your password here" htmlFor="cpassword" name="cpassword" type="password" onChange={confirmHandler} />
                  {confirm ? <span>*required</span> : ""}
                </FormGroup>
                <FormGroup className="contact__form">
                  <Input placeholder="Enter your address" htmlFor="address" type="text" onChange={addressHandler} name="address" />
                  {address ? <span>*required</span> : ""}
                </FormGroup>

                <button className=" contact__btn" type="submit" >
                  Register
                </button>
              </Form>
            </Col>

            <Col lg="5" md="5">
              <div className="contact__info">
                <h6 className="fw-bold">Contact Information</h6>
                <p className="section__description mb-0">
                  456 Koramangala Avenue, HSR Layout, Bangalore
                </p>
                <div className=" d-flex align-items-center gap-2">
                  <h6 className="fs-6 mb-0">Phone:</h6>
                  <p className="section__description mb-0">+917891234567</p>
                </div>

                <div className=" d-flex align-items-center gap-2">
                  <h6 className="mb-0 fs-6">Email:</h6>
                  <p className="section__description mb-0">bangalorerentalservice@gmail.com </p>
                </div>

                <h6 className="fw-bold mt-4">Follow Us</h6>

                <div className=" d-flex align-items-center gap-4 mt-3">
                  {socialLinks.map((item, index) => (
                    <Link
                      to={item.url}
                      key={index}
                      className="social__link-icon"
                    >
                      <i class={item.icon}></i>
                    </Link>
                  ))}
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
    </Helmet>
  );
};

export default Register;
