import React from "react";
import Slider from "react-slick";

import "../../styles/testimonial.css";

import ava01 from "../../assets/all-images/1.jpg";
import ava02 from "../../assets/all-images/2.jpg";
import ava03 from "../../assets/all-images/3.jpg";
import ava04 from "../../assets/all-images/4.jpg";
import ava05 from "../../assets/all-images/5.jpg";
import ava06 from "../../assets/all-images/6.jpg";
import ava07 from "../../assets/all-images/7.jpg";
import ava08 from "../../assets/all-images/8.jpg";

const Testimonial = () => {
  const settings = {
    dots: true,
    infinite: true,
    autoplay: true,
    speed: 1000,
    swipeToSlide: true,
    autoplaySpeed: 2000,
    slidesToShow: 3,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
          dots: true,
        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };
  return (
    <Slider {...settings}>

      <div className="testimonial py-4 px-3">
        <p className="section__description">
         The convenience of having a car without the hassles of maintenance is unparalleled. Thanks to GoCarz for their fantastic service!
        </p>
        <div className="mt-3 d-flex align-items-center gap-4">
          <img src={ava01} alt="" className="w-25 h-25 rounded-2" />
          <div>
            <h6 className="mb-0 mt-3">Amit Sharma</h6>
            <p className="section__description">Customer</p>
          </div>
        </div>
      </div>

      <div className="testimonial py-4 px-3">
        <p className="section__description">
          Loved the variety of cars on offer. The process was seamless and hassle-free. Highly recommended for anyone in need of a temporary ride.
        </p>
        <div className="mt-3 d-flex align-items-center gap-4">
          <img src={ava02} alt="" className="w-25 h-25 rounded-2" />
          <div>
            <h6 className="mb-0 mt-3">Sunita Rao</h6>
            <p className="section__description">Customer</p>
          </div>
        </div>
      </div>

      <div className="testimonial py-4 px-3">
        <p className="section__description">
          I took a car for a weekend getaway with my family. The car was clean and in excellent condition. The whole experience was a pleasure!
        </p>
        <div className="mt-3 d-flex align-items-center gap-4">
          <img src={ava03} alt="" className="w-25 h-25 rounded-2" />
          <div>
            <h6 className="mb-0 mt-3">Nidhi Agarwal</h6>
            <p className="section__description">Customer</p>
          </div>
        </div>
      </div>

      <div className="testimonial py-4 px-3">
        <p className="section__description">
          From booking to return, the process was transparent and easy. The staff were helpful, and the car was in great shape. Will use GoCarz again for sure!
        </p>
        <div className="mt-3 d-flex align-items-center gap-4">
          <img src={ava04} alt="" className="w-25 h-25 rounded-2" />
          <div>
            <h6 className="mb-0 mt-3">Priya Mehta</h6>
            <p className="section__description">Customer</p>
          </div>
        </div>
      </div>

      <div className="testimonial py-4 px-3">
        <p className="section__description">
          Needed a car for a business trip and GoCarz saved the day. Professional service and great cars at affordable prices!
        </p>
        <div className="mt-3 d-flex align-items-center gap-4">
          <img src={ava05} alt="" className="w-25 h-25 rounded-2" />
          <div>
            <h6 className="mb-0 mt-3">Kunal Joshi</h6>
            <p className="section__description">Customer</p>
          </div>
        </div>
      </div>

      <div className="testimonial py-4 px-3">
        <p className="section__description">
          I’ve been using GoCarz for a few months now for my daily commute. Reliable, on time, and budget-friendly. Thanks, GoCarz!
        </p>
        <div className="mt-3 d-flex align-items-center gap-4">
          <img src={ava06} alt="" className="w-25 h-25 rounded-2" />
          <div>
            <h6 className="mb-0 mt-3">Anush Reddy</h6>
            <p className="section__description">Customer</p>
          </div>
        </div>
      </div>

      <div className="testimonial py-4 px-3">
        <p className="section__description">
          Had to travel inter-city for an emergency. GoCarz was prompt in providing a vehicle even at the last minute. Great service!
        </p>
        <div className="mt-3 d-flex align-items-center gap-4">
          <img src={ava07} alt="" className="w-25 h-25 rounded-2" />
          <div>
            <h6 className="mb-0 mt-3">Rohan Nair</h6>
            <p className="section__description">Customer</p>
          </div>
        </div>
      </div>

      <div className="testimonial py-4 px-3">
        <p className="section__description">
          Took a car for a week-long trip. The journey was smooth, and the car was well-maintained. Kudos to the GoCarz team!
        </p>
        <div className="mt-3 d-flex align-items-center gap-4">
          <img src={ava08} alt="" className="w-25 h-25 rounded-2" />
          <div>
            <h6 className="mb-0 mt-3">Rahul Varma</h6>
            <p className="section__description">Customer</p>
          </div>
        </div>
      </div>

    </Slider>
  );
};

export default Testimonial;
