import React from "react";
import "../../styles/booking-form.css";
import { Form, FormGroup } from "reactstrap";
import axios from 'axios';
import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";

const BookingForm = () => {
  const [values, setValues] = useState({
    first: '',
    last: '',
    email: '',
    phone: '',
    from: '',
    to: '',
    dob: '',
  })
  const dataHandler = (e) => {
    if (e.target.value === "") {
      alert("please fill each column")
    }
    else {
      setValues({ ...values, [e.target.name]: [e.target.value] })
    }
  }
  const navigate = useNavigate()
  const submitHandler = (event) => {
    if (!first && !last && !from && !to && !email) {
      event.preventDefault();
      axios.post('http://localhost:8081/book', values)
        .then(res => console.log('successful'))
        .catch(err => console.log(err))
      alert("booked successfully")
      navigate('/home')
    }
    else {
      alert("please fill each row")
    }

  };
  const [first, setFirst] = useState(true);
  const [last, setLast] = useState(true);
  const [password, setPassword] = useState(true);
  const [email, setEmail] = useState(true);
  const [confirm, confirmPass] = useState(true);
  const [from, setFrom] = useState(true);
  const [to, setTo] = useState(true);
  const [date, setDate] = useState(true);
  const [number, setNumber] = useState(true);


  function nameHandler(e) {
    let item = e.target.value;
    if (item === "") {
      setFirst(true);


    }
    else {
      setValues({ ...values, [e.target.name]: [e.target.value] })

      setFirst(false);

    }

  }
  function namingHandler(e) {
    let item = e.target.value;
    if (item === "") {
      setLast(true);


    }
    else {
      setValues({ ...values, [e.target.name]: [e.target.value] })

      setLast(false);

    }

  }
  function passwordHandler(e) {
    let item = e.target.value;
    if (item === "") {
      setPassword(true);

    }
    else {
      setValues({ ...values, [e.target.name]: [e.target.value] })
      setPassword(false);

    }

  }
  function emailHandler(e) {
    let item = e.target.value;
    if (item === "") {
      setEmail(true);

    }
    else {
      setValues({ ...values, [e.target.name]: [e.target.value] })

      setEmail(false);

    }

  }
  function confirmHandler(e) {
    let item = e.target.value;
    if (item === "") {
      confirmPass(true);

    }
    else {


      confirmPass(false);

    }

  }
  function fromHandler(e) {
    let item = e.target.value;
    if (item === "") {
      setFrom(true);

    }
    else {

      setValues({ ...values, [e.target.name]: [e.target.value] })

      setFrom(false);


    }
  }
  function toHandler(e) {
    let item = e.target.value;
    if (item === "") {
      setTo(true);

    }
    else {

      setValues({ ...values, [e.target.name]: [e.target.value] })

      setTo(false);


    }

  }
  function numberHandler(e) {
    let item = e.target.value;
    if (item === "") {
      setNumber(true);

    }
    else {

      setValues({ ...values, [e.target.name]: [e.target.value] })

      setNumber(false);


    }

  }
  function dateHandler(e) {
    let item = e.target.value;
    if (item === "") {
      setDate(true);

    }
    else {

      setValues({ ...values, [e.target.name]: [e.target.value] })

      setDate(false);


    }

  }


  return (
    <Form onSubmit={submitHandler}>
      <FormGroup className="booking__form d-inline-block me-4 mb-4" >
        <input type="text" placeholder="First Name" name="first" onChange={nameHandler} />
        {first ? <span>*required</span> : ""}
      </FormGroup>
      <FormGroup className="booking__form d-inline-block ms-1 mb-4" >
        <input type="text" placeholder="Last Name" name="last" onChange={namingHandler} />
        {last ? <span>*required</span> : ""}
      </FormGroup>

      <FormGroup className="booking__form d-inline-block me-4 mb-4" >
        <input type="email" placeholder="Email" name="email" onChange={emailHandler} />
        {email ? <span>*required</span> : ""}
      </FormGroup>
      <FormGroup className="booking__form d-inline-block ms-1 mb-4">
        <input type="number" placeholder="Phone Number" name="phone" onChange={numberHandler} />
        {number ? <span>*required</span> : ""}
      </FormGroup>

      <FormGroup className="booking__form d-inline-block me-4 mb-4" >
        <input type="text" placeholder="From Address" name="from" onChange={fromHandler} />
        {from ? <span>*required</span> : ""}
      </FormGroup>
      <FormGroup className="booking__form d-inline-block ms-1 mb-4" >
        <input type="text" placeholder="To Address" name="to" onChange={toHandler} />
        {to ? <span>*required</span> : ""}
      </FormGroup>

      <FormGroup className="booking__form d-inline-block me-4 mb-4">
        <input type="date" placeholder="Journey Date" name="dob" onChange={dateHandler} />
      </FormGroup>
      <div className="payment text-end mt-5">
        <button>Book Now</button>
      </div>

    </Form>
  );
};

export default BookingForm;
