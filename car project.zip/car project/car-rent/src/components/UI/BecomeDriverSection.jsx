import React from "react";
import "../../styles/become-driver.css";
import { Container, Row, Col } from "reactstrap";



const BecomeDriverSection = () => {
  return (
    <section className="become__driver">
      <Container>
        
      </Container>
    </section>
  );
};

export default BecomeDriverSection;
