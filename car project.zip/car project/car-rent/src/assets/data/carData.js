// import all images from assets/images directory
import img01 from "../all-images/cars-img/1.jpg";
import img02 from "../all-images/cars-img/2.jpeg";
import img03 from "../all-images/cars-img/Tata-Nexon-220920231520.jpeg";
import img04 from "../all-images/cars-img/4.jpg";
import img05 from "../all-images/cars-img/Maruti-Suzuki-Baleno-040320222001.jpg";
import img06 from "../all-images/cars-img/i20-exterior-right-front-three-quarter-7.jpeg";
import img07 from "../all-images/cars-img/Kia-Seltos-040720231714.jpg";
import img08 from "../all-images/cars-img/Toyota-Innova-Crysta-facelift-sliver-studio.jpg";
import img09 from "../all-images/cars-img/MG-Hector-100220231534.jpg";


const carData = [
  {
    id: 1,
    brand: "Maruti Suzuki",
    carName: "Maruti Suzuki Swift",
    model: "Swift 2022",
    automatic: "Automatic",
    speed: "160 km/h",
    price: "₹2,000",
    description: "One of the top-selling cars in India, known for its compact design and efficient performance.",
    imgUrl: img01,
  },
  {
    id: 2,
    brand: "Hyundai",
    carName: "Hyundai Creta",
    model: "Creta 2022",
    automatic: "Automatic",
    speed: "190 km/h",
    price: "₹4,457",
    description: "A popular mid-sized SUV with stylish looks and a comfortable ride.",
    imgUrl: img02,
  },
  {
    id: 3,
    brand: "Tata",
    carName: "Tata Nexon",
    model: "Nexon XZ+",
    automatic: "Automatic",
    speed: "170 km/h",
    price: "₹3,434",
    description: "A compact SUV from Tata Motors, well-received for its design and safety features.",
    imgUrl: img03,
  },
  {
    id: 4,
    brand: "Mahindra",
    carName: "Mahindra Thar",
    model: "Thar LX",
    automatic: "Automatic",
    speed: "150 km/h",
    price: "₹6,754",
    description: "An off-roading SUV with a rugged design, the 2020 version was particularly popular.",
    imgUrl: img04,
  },
  {
    id: 5,
    brand: "Maruti Suzuki",
    carName: "Maruti Suzuki Baleno",
    model: "Baleno Alpha",
    automatic: "Automatic",
    speed: "180 km/h",
    price: "₹5,999",
    description: "A premium hatchback with a spacious interior and stylish design.",
    imgUrl: img05,
  },
  {
    id: 6,
    brand: "Hyundai",
    carName: "Hyundai i20",
    model: "i20 Asta",
    automatic: "Automatic",
    speed: "175 km/h",
    price: "₹4,999",
    description: "Another premium hatchback, known for its features and smooth driving experience.",
    imgUrl: img06,
  },
  {
    id: 7,
    brand: "Kia",
    carName: "Kia Seltos",
    model: "Seltos HTX",
    automatic: "Automatic",
    speed: "185 km/h",
    price: "₹9,000",
    description: "Kia's entry into the Indian market with this mid-sized SUV was a huge success.",
    imgUrl: img07,
  },
  {
    id: 8,
    brand: "Toyota",
    carName: "Toyota Innova Crysta",
    model: "Innova Crysta 2.4 GX",
    automatic: "No",
    speed: "180 km/h",
    price: "₹12,000",
    description:"A multipurpose vehicle (MPV) popular among families and fleet operators.",
    imgUrl: img08,
  },
  {
    id: 9,
    brand: "MG",
    carName: "MG Hector",
    model: "Hector Sharp",
    automatic: "Automatic",
    speed: "190 km/h",
    price: "₹13,000",
    description: "Morris Garages (MG)'s mid-sized SUV with advanced features, it garnered a lot of attention in the Indian market.",
    imgUrl: img09,
  },
 
];




export default carData;
