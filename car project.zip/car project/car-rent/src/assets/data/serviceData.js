const serviceData = [

  {
    id: 3,
    title: "Unlimited Miles Car Rental",
    icon: "ri-roadster-line",
    desc:"Be it for shopping, meeting your relatives, going on a historical or food tour, or just for meetings, with Savaari’s local hourly car rental service in Bangalore options such as 8 hr 80 km, 12 hr 120 Km your travel within the city is taken care of",
  },

  {
    id: 4,
    title: "Fast & Easy Booking",
    icon: "ri-timer-flash-line",
    desc: "Get picked up at your doorstep, wherever you are, without paying an extra fee. This means that you don't have to worry about finding transportation to get to the rental car or worrying about parking the car upon returning it..",
  },


  {
    id: 6,
    title: "Airport Transfer",
    icon: "ri-flight-takeoff-line",
    desc: " No more waiting in the long queue for cabs at the airport or worrying about missing your flight. Effortlessly book your reliable airport car rental in Bangalore for transfers from Kempegowda International Airport or to any location in the city.",
  },
];

export default serviceData;
