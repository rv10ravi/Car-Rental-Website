// import images from all-images/blog-img directory
import img01 from "../all-images/blog-img/blog-1.jpg";
import img02 from "../all-images/blog-img/blog-2.jpg";
import img03 from "../all-images/blog-img/blog-3.jpg";

const blogData = [
  {
    id: 1,
    title: "The best way to drive cars",
    imgUrl: img01,
    description:
      "Find the correct seating position: The seating position is crucial for a driver as it impacts the visibility and access to various car controls. Find a seating position that suits you. You can play around with the seat adjustment options to find a sweet spot. Adjust the seat in such a way that your thighs and back are not strained. At the same time, you should easily access the pedals, steering wheel and other controls. Familiarise yourself with controls, adjust mirrors: Acquaint yourself with the car before you take out the vehicle for a drive. Understand all the controls and features, and functions of the various buttons/knobs present in the cabin. Get used to the pedals and ensure that you can efficiently operate them. Get familiar with the gear lever and understand the shift pattern. Next, adjust the ORVMs (Outside Rear View Mirrors) and IRVM (Inside Rear View Mirror). Ensure that you get a good view of what’s going on behind. Hold the steering wheel properly: As a beginner driver, you may tend to overlook this point. But holding the steering wheel in the correct position is crucial. Always stick to the 10 o’clock or 2 o’clock position and use the steering wheel with both hands unless you shift gears. Be smooth and gentle with the steering inputs.Don’t rest your hand on the gear lever: It is one of the most common mistakes that beginner drivers make when driving a manual car. Do not rest your hand on the gear lever as it transfers the weight onto the lever, resulting in the wear and tear of internal components of the gearbox. Moreover, it’s not safe to drive with one hand on the steering wheel.Try driving in the daytime and in good weather: As a beginner driver, try to drive during day time. Visibility is crucial, especially with limited driving experience, and driving after sundown could cause problems due to poor visibility. Also, avoid driving in bad weather conditions. For instance, avoid taking the car out during thunderstorms.",
    quote:
    "Patience is something you admire in the driver behind you and scorn in the one ahead",
  },

  {
    id: 2,
    title: "If your car battery is down",
    imgUrl: img02,
    description:
      "The most common way to deal with a dead battery is by jump-starting it. All you need to jump-start a car is a set of jumper cables and another car (a good Samaritan) with a functional battery. Keep in mind that you should never try to jump-start a car if its battery is cracked and is visibly leaking acid.Take out your jumper cables.It's a good idea to buy a set of jumper cables and keep them in your car. If you don't have jumper cables, you have to find a good Samaritan who not only is willing to assist you but who has jumper cables as well.",
    quote:
      "Adventure is worthwhile in itself",
  },

  {
    id: 3,
    title: "The best way to give trip",
    
    imgUrl: img03,
    description:
      " It's a weird time, and so you need to think through things that used to just be extras when it came to trip planning. For example, if they need a rental car, you'll want to make sure that price and availability aren't going to be a problem.Some ski resorts also limit lift ticket sales during peak dates, so if you are gifting them a ski trip, make sure they can still get lift tickets. Even Disney World sells out of tickets on certain dates, so ensure you make them Park Pass reservations to go along with gifted tickets in the case of a theme park trip tied to specific dates.Basically, go through all components of the trip and pre-plan or at least adequately research the availability of all of the essential components.",
    quote:
      "Wherever you are, be all there",
  },
];

export default blogData;
