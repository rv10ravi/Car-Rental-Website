const express = require("express");
const mysql = require("mysql");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "CAR",
  port: "3306",
});
db.connect((err) => {
  if (err) {
    console.log(err);
  } else {
    console.log("connected");
  }
});

app.post("/register", (req, res) => {
  const sql =
    "INSERT INTO customerInfo (`name`,`email`,`password`,`address`) VALUES (?)";
  const values = [
    req.body.name,
    req.body.email,
    req.body.password,
    req.body.address,
  ];
  console.log(values);
  db.query(sql, [values], (err, data) => {
    if (err) return res.json(err);
    return res.json(data);
  });
});

app.post("/contact", (req, res) => {
  const sql = "INSERT INTO contact (`name`,`email`,`message`) VALUES (?)";
  const values = [req.body.name, req.body.email, req.body.message];
  console.log(values);
  db.query(sql, [values], (err, data) => {
    if (err) return res.json(err);
    return res.json(data);
  });
});

var info = {};
app.post("/login", (req, res) => {
  const sql = "SELECT * FROM customerInfo where email = ? and password = ?";
  const values = [req.body.email, req.body.password];
  // console.log(values)
  db.query(sql, [req.body.email, req.body.password], (err, data) => {
    if (err) return res.json("Error");
    console.log(data);
    info = {
      name: data[0]["name"],
      email: data[0]["email"],
      password: data[0]["password"],
      address: data[0]["address"],
    };
    // console.log(info)
    if (data.length > 0) {
      console.log("user exist");
      return res.json(data);
    } else {
      console.log(
        "user does not exist please check your password or register if not registered"
      );
      return res.json("No record");
    }
  });
});
app.get("/users", (req, res) => {
  res.json(info);
});
app.post("/book", (req, res) => {
  const sql =
    "INSERT INTO booking (`first`,`last`,`email`,`phone`,`from`,`to`,`dob`) VALUES (?)";
  const values = [
    req.body.first,
    req.body.last,
    req.body.email,
    req.body.phone,
    req.body.from,
    req.body.to,
    req.body.dob,
  ];
  console.log(values);
  db.query(sql, [values], (err, data) => {
    if (err) return res.json(err);
    return res.json(data);
  });
});
app.listen(8081, () => {
  console.log("Listening ......");
});
